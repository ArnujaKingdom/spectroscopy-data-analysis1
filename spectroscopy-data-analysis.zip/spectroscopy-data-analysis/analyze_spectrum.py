"""UV-Vis spectroscopy analysis using simulated educational data."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA_FILE = Path(__file__).with_name("simulated_uvvis_data.csv")
OUTPUT_FILE = Path(__file__).with_name("uvvis_spectrum.png")

def main():
    data = pd.read_csv(DATA_FILE)
    required = {"wavelength_nm", "absorbance_au"}
    missing = required - set(data.columns)
    if missing:
        raise ValueError(f"Missing required CSV columns: {sorted(missing)}")
    data = data.dropna(subset=["wavelength_nm", "absorbance_au"])
    if data.empty:
        raise ValueError("The dataset has no valid measurements.")

    peak = data.loc[data["absorbance_au"].idxmax()]
    print("UV-Vis Spectroscopy Data Analysis")
    print("---------------------------------")
    print(f"Number of valid rows: {len(data)}")
    print(f"Maximum absorbance: {peak['absorbance_au']:.4f} a.u.")
    print(f"Wavelength at maximum absorbance: {peak['wavelength_nm']:.1f} nm")
    print("Note: simulated practice data, not an experimental result.")

    plt.figure(figsize=(8, 5))
    plt.plot(data["wavelength_nm"], data["absorbance_au"],
             marker="o", markersize=3, linewidth=1.5,
             label="Simulated UV-Vis data")
    plt.scatter([peak["wavelength_nm"]], [peak["absorbance_au"]],
                label=f"Maximum: {peak['wavelength_nm']:.0f} nm")
    plt.xlabel("Wavelength (nm)")
    plt.ylabel("Absorbance (a.u.)")
    plt.title("UV-Vis Absorption Spectrum (Simulated Data)")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_FILE, dpi=300)
    print(f"Graph saved to: {OUTPUT_FILE.name}")
    plt.show()

if __name__ == "__main__":
    main()
