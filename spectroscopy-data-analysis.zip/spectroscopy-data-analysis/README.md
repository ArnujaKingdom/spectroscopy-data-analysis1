# UV-Vis Spectroscopy Data Analysis

A beginner-friendly Python project that reads wavelength–absorbance data from a CSV file, finds the wavelength of maximum absorbance, and plots the spectrum.

> **Data integrity:** The included dataset is simulated for practice. It is not experimental data and does not represent a measured perovskite sample.

## Files
- `simulated_uvvis_data.csv` — simulated wavelength and absorbance values.
- `analyze_spectrum.py` — analysis and plotting script.
- `uvvis_spectrum.png` — example graph.

## Requirements
Python 3, pandas, and Matplotlib.

Install dependencies:
```bash
python -m pip install pandas matplotlib
```

## Run
Keep the CSV and Python file in the same folder, then run:
```bash
python analyze_spectrum.py
```

The script reports the number of valid rows, maximum absorbance, and wavelength at maximum absorbance. It saves `uvvis_spectrum.png`.

## Method
1. Read the CSV using pandas.
2. Check for the required columns.
3. Remove rows with missing wavelength or absorbance values.
4. Find the row with maximum absorbance.
5. Plot absorbance against wavelength and mark the maximum.

## Example result
The included simulated dataset peaks at approximately **0.8634 a.u. at 485 nm**.

## Scientific limitations
A peak wavelength alone does not identify a material or establish its optical band gap. Real spectra may require blank subtraction, baseline correction, replicate measurements, and careful instrument settings. Do not present this simulated result as an experimental finding.

## Future improvements
- Compare multiple spectra on one graph.
- Add baseline correction and smoothing with documented parameters.
- Analyse experimental data that you have permission to share.
- Add tests for missing columns and invalid values.
